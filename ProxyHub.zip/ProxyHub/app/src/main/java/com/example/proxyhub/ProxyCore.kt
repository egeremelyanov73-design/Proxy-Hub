package com.example.proxyhub

/**
 * Точка подключения реального ядра (Xray) и VpnService.
 *
 * Сейчас стоит заглушка: приложение импортирует и хранит конфигурации, но трафик
 * не туннелирует. Чтобы заработало подключение, нужно:
 *  1. добавить библиотеку Xray для Android (libv2ray / AndroidLibXrayLite) как .aar;
 *  2. написать VpnService, который поднимает TUN-интерфейс;
 *  3. сконвертировать ссылку сервера (vless://, vmess:// ...) в JSON-конфиг Xray;
 *  4. реализовать этот интерфейс и подставить в MainViewModel вместо StubCore.
 */
interface ProxyCore {
    /** true, если подключено настоящее ядро. */
    val isReal: Boolean
    fun start(server: Server)
    fun stop()
}

class StubCore : ProxyCore {
    override val isReal = false
    override fun start(server: Server) = Unit
    override fun stop() = Unit
}

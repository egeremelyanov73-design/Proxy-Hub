package com.example.proxyhub

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardColors
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

// ---------------------------------------------------------------- буфер обмена

fun readClipboard(ctx: Context): String {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip ?: return ""
    if (clip.itemCount == 0) return ""
    return clip.getItemAt(0).coerceToText(ctx)?.toString().orEmpty()
}

fun writeClipboard(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

@Composable
private fun panelColors(): CardColors = CardDefaults.cardColors(
    containerColor = MaterialTheme.colorScheme.surface,
    contentColor = MaterialTheme.colorScheme.onSurface,
)

// ---------------------------------------------------------------- корень

@Composable
fun ProxyHubApp(vm: MainViewModel) {
    MaterialTheme(colorScheme = vm.theme.toColorScheme()) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            var screen by rememberSaveable { mutableStateOf("main") }
            val snackbar = remember { SnackbarHostState() }
            LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                containerColor = MaterialTheme.colorScheme.background,
            ) { padding ->
                Box(Modifier.padding(padding)) {
                    if (screen == "main") {
                        MainScreen(vm, onSettings = { screen = "settings" })
                    } else {
                        BackHandler { screen = "main" }
                        SettingsScreen(vm, onBack = { screen = "main" })
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- главный экран

@Composable
fun MainScreen(vm: MainViewModel, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Proxy Hub",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            // Кнопка настроек — в правом верхнем углу
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, contentDescription = "Настройки") }
        }

        ConnectionCard(vm)

        Spacer(Modifier.height(12.dp))
        Text("Профили", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (vm.busy) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp))
        }

        if (vm.profiles.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    "Профилей пока нет.\nСкопируйте ссылку в боте и нажмите «Вставить из буфера обмена».",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(Modifier.weight(1f).padding(top = 6.dp)) {
                items(vm.profiles, key = { it.id }) { ProfileCard(vm, it) }
            }
        }

        Column(Modifier.padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { vm.importText(readClipboard(ctx)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Вставить из буфера обмена") }
            OutlinedButton(
                onClick = { scanQr(ctx, vm) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Сканировать QR-код") }
        }
    }
}

private fun scanQr(ctx: Context, vm: MainViewModel) {
    val options = GmsBarcodeScannerOptions.Builder()
        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
        .build()
    GmsBarcodeScanning.getClient(ctx, options).startScan()
        .addOnSuccessListener { barcode ->
            val value = barcode.rawValue
            if (value.isNullOrBlank()) vm.toast("QR-код пустой") else vm.importText(value)
        }
        .addOnFailureListener { vm.toast("Не удалось открыть сканер QR (нужны сервисы Google Play)") }
}

@Composable
fun ConnectionCard(vm: MainViewModel) {
    Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = panelColors()) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (vm.connected) "Подключено" else "Отключено",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                vm.selectedServer()?.name ?: "Сервер не выбран",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (!vm.core.isReal) {
                Text(
                    "Ядро Xray не подключено — трафик пока не туннелируется",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            Button(onClick = { vm.toggleConnection() }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Text(if (vm.connected) "Отключить" else "Подключить")
            }
        }
    }
}

@Composable
fun ProfileCard(vm: MainViewModel, profile: Profile) {
    var expanded by rememberSaveable(profile.id) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = panelColors()) {
        Column {
            Row(
                Modifier.fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(profile.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "Серверов: ${profile.servers.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (profile.sourceUrl != null) {
                    IconButton(onClick = { vm.refresh(profile) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Обновить подписку")
                    }
                }
                IconButton(onClick = { vm.delete(profile) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить")
                }
            }
            if (expanded) {
                profile.servers.forEach { server ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { vm.select(server.link) }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(server.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (server.link == vm.selectedLink) {
                            Icon(Icons.Default.Check, contentDescription = "Выбран", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- настройки

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var pickerKey by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад") }
            Text("Настройки", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        // === Самый верх настроек: «Настройки тем» ===
        Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = panelColors()) {
            Column(Modifier.padding(16.dp)) {
                Text("Настройки тем", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                ThemeColors.KEYS.forEach { key ->
                    ColorRow(
                        label = ThemeColors.LABELS.getValue(key),
                        hex = vm.theme.hex(key),
                        onClick = { pickerKey = key },
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { vm.pasteTheme(readClipboard(ctx)) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Вставить тему из буфера обмена") }
                OutlinedButton(
                    onClick = {
                        writeClipboard(ctx, "theme", vm.theme.toJson())
                        vm.toast("Тема скопирована в буфер обмена")
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                ) { Text("Скопировать текущую тему") }
                TextButton(
                    onClick = { vm.resetTheme() },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Сбросить тему") }
                Text(
                    "Формат: {\"bg\":\"#12141a\",\"panel\":\"#1d2029\",\"accent\":\"#4f8cff\",\"text\":\"#e8eaf0\",\"muted\":\"#8a90a0\"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.height(24.dp))
    }

    pickerKey?.let { key ->
        ColorPickerDialog(
            title = ThemeColors.LABELS.getValue(key),
            initialHex = vm.theme.hex(key),
            onDismiss = { pickerKey = null },
            onPick = { hex ->
                vm.setThemeColor(key, hex)
                pickerKey = null
            },
        )
    }
}

@Composable
fun ColorRow(label: String, hex: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Text(hex, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 12.dp))
        Box(
            Modifier.size(32.dp).clip(shape).background(parseHex(hex))
                .border(1.dp, MaterialTheme.colorScheme.outline, shape)
        )
    }
}

@Composable
fun ColorPickerDialog(title: String, initialHex: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val initial = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(android.graphics.Color.parseColor(initialHex), it) }
    }
    var h by remember { mutableFloatStateOf(initial[0]) }
    var s by remember { mutableFloatStateOf(initial[1]) }
    var v by remember { mutableFloatStateOf(initial[2]) }

    fun currentHex(): String =
        String.format("#%06x", android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF)

    var hexInput by remember { mutableStateOf(currentHex()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Box(
                    Modifier.fillMaxWidth().height(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(parseHex(currentHex()))
                )
                Text("Оттенок")
                Slider(value = h, onValueChange = { h = it; hexInput = currentHex() }, valueRange = 0f..360f)
                Text("Насыщенность")
                Slider(value = s, onValueChange = { s = it; hexInput = currentHex() }, valueRange = 0f..1f)
                Text("Яркость")
                Slider(value = v, onValueChange = { v = it; hexInput = currentHex() }, valueRange = 0f..1f)
                OutlinedTextField(
                    value = hexInput,
                    onValueChange = { text ->
                        hexInput = text
                        if (ThemeColors.HEX.matches(text)) {
                            val hsv = FloatArray(3)
                            android.graphics.Color.colorToHSV(android.graphics.Color.parseColor(text), hsv)
                            h = hsv[0]; s = hsv[1]; v = hsv[2]
                        }
                    },
                    label = { Text("HEX (#RRGGBB)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onPick(if (ThemeColors.HEX.matches(hexInput)) hexInput.lowercase() else currentHex())
            }) { Text("Применить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

package com.example.proxyhub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Хранение профилей, выбранного сервера и темы в SharedPreferences. */
class Storage(context: Context) {
    private val sp = context.getSharedPreferences("proxyhub", Context.MODE_PRIVATE)

    fun loadProfiles(): List<Profile> = try {
        val arr = JSONArray(sp.getString("profiles", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val servers = o.getJSONArray("servers")
            Profile(
                id = o.getString("id"),
                name = o.getString("name"),
                sourceUrl = if (o.isNull("source")) null else o.getString("source"),
                servers = (0 until servers.length()).map { j ->
                    val s = servers.getJSONObject(j)
                    Server(s.getString("name"), s.getString("link"))
                },
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        for (p in list) {
            val servers = JSONArray()
            for (s in p.servers) {
                servers.put(JSONObject().put("name", s.name).put("link", s.link))
            }
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("source", p.sourceUrl ?: JSONObject.NULL)
                    .put("servers", servers)
            )
        }
        sp.edit().putString("profiles", arr.toString()).apply()
    }

    var selectedLink: String?
        get() = sp.getString("selected", null)
        set(value) {
            sp.edit().putString("selected", value).apply()
        }

    fun loadTheme(): ThemeColors {
        val saved = sp.getString("theme", null) ?: return ThemeColors()
        return try {
            ThemeColors.applyJson(ThemeColors(), saved)
        } catch (e: IllegalArgumentException) {
            ThemeColors()
        }
    }

    fun saveTheme(theme: ThemeColors) {
        sp.edit().putString("theme", theme.toJson()).apply()
    }
}

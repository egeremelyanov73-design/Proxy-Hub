package com.example.proxyhub

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import org.json.JSONException
import org.json.JSONObject

/**
 * Цвета темы в виде #RRGGBB. Именно этот JSON можно копировать и вставлять
 * в «Настройки → Настройки тем»:
 * {"bg":"#12141a","panel":"#1d2029","accent":"#4f8cff","text":"#e8eaf0","muted":"#8a90a0"}
 */
data class ThemeColors(
    val bg: String = "#12141a",
    val panel: String = "#1d2029",
    val accent: String = "#4f8cff",
    val text: String = "#e8eaf0",
    val muted: String = "#8a90a0",
) {
    fun hex(key: String): String = when (key) {
        "bg" -> bg
        "panel" -> panel
        "accent" -> accent
        "text" -> text
        else -> muted
    }

    fun withColor(key: String, value: String): ThemeColors = when (key) {
        "bg" -> copy(bg = value)
        "panel" -> copy(panel = value)
        "accent" -> copy(accent = value)
        "text" -> copy(text = value)
        else -> copy(muted = value)
    }

    fun toJson(): String = JSONObject()
        .put("bg", bg).put("panel", panel).put("accent", accent)
        .put("text", text).put("muted", muted)
        .toString()

    companion object {
        val KEYS = listOf("bg", "panel", "accent", "text", "muted")
        val LABELS = mapOf(
            "bg" to "Фон",
            "panel" to "Панели",
            "accent" to "Акцент",
            "text" to "Текст",
            "muted" to "Второстепенный текст",
        )
        val HEX = Regex("^#[0-9a-fA-F]{6}$")

        /** Применяет JSON-тему поверх [base]. Бросает IllegalArgumentException с понятным текстом. */
        fun applyJson(base: ThemeColors, text: String): ThemeColors {
            val obj = try {
                JSONObject(text.trim())
            } catch (e: JSONException) {
                throw IllegalArgumentException("В буфере обмена нет темы в формате JSON")
            }
            var result = base
            var found = false
            for (key in KEYS) {
                if (!obj.has(key)) continue
                val value = obj.optString(key).trim()
                require(HEX.matches(value)) { "Цвет «$key» должен быть в формате #RRGGBB" }
                result = result.withColor(key, value.lowercase())
                found = true
            }
            require(found) { "В теме нет известных цветов (${KEYS.joinToString()})" }
            return result
        }
    }
}

fun parseHex(hex: String): Color = Color(android.graphics.Color.parseColor(hex))

fun contrastOn(color: Color): Color = if (color.luminance() > 0.5f) Color.Black else Color.White

fun ThemeColors.toColorScheme(): ColorScheme {
    val accentC = parseHex(accent)
    val panelC = parseHex(panel)
    return darkColorScheme(
        primary = accentC,
        onPrimary = contrastOn(accentC),
        secondary = accentC,
        background = parseHex(bg),
        onBackground = parseHex(text),
        surface = panelC,
        onSurface = parseHex(text),
        surfaceVariant = panelC,
        onSurfaceVariant = parseHex(muted),
        outline = parseHex(muted),
    )
}

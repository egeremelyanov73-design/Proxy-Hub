package com.example.proxyhub

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import java.net.URI
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val storage = Storage(app)

    /** Замените на реальную реализацию, когда подключите Xray (см. ProxyCore.kt). */
    val core: ProxyCore = StubCore()

    var profiles by mutableStateOf(storage.loadProfiles()); private set
    var theme by mutableStateOf(storage.loadTheme()); private set
    var selectedLink by mutableStateOf(storage.selectedLink); private set
    var connected by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set

    private val messageChannel = Channel<String>(Channel.BUFFERED)
    val messages = messageChannel.receiveAsFlow()

    fun toast(text: String) {
        messageChannel.trySend(text)
    }

    // ---------------------------------------------------------------- импорт

    fun importText(text: String) {
        val items = LinkParser.parse(text)
        if (items.isEmpty()) {
            toast("В буфере обмена пусто")
            return
        }
        viewModelScope.launch {
            busy = true
            var added = 0
            var serverCount = 0
            val errors = mutableListOf<String>()
            for (item in items) {
                when (item) {
                    is Item.Subscription -> {
                        try {
                            val result = SubscriptionClient.fetch(item.url)
                            if (result.links.isEmpty()) {
                                errors += "В подписке нет поддерживаемых серверов"
                            } else {
                                upsertSubscription(item.url, result.title, result.links)
                                added++
                                serverCount += result.links.size
                            }
                        } catch (e: Exception) {
                            errors += "Не удалось загрузить подписку: ${e.message ?: e.javaClass.simpleName}"
                        }
                    }
                    is Item.ServerLink -> {
                        if (addSingle(item.link)) {
                            added++
                            serverCount++
                        }
                    }
                    is Item.Unsupported -> errors += item.reason
                }
            }
            busy = false
            toast(
                buildString {
                    if (added > 0) append("Добавлено профилей: $added, серверов: $serverCount")
                    if (errors.isNotEmpty()) {
                        if (isNotEmpty()) append("\n")
                        append(errors.distinct().joinToString("\n"))
                    }
                    if (isEmpty()) append("Эти серверы уже добавлены")
                }
            )
        }
    }

    private fun upsertSubscription(url: String, title: String?, links: List<String>) {
        val servers = links.map { Server(LinkParser.serverName(it), it) }
        val existing = profiles.firstOrNull { it.sourceUrl == url }
        val name = title
            ?: existing?.name
            ?: runCatching { URI(url).host }.getOrNull()
            ?: "Подписка"
        val profile = Profile(existing?.id ?: UUID.randomUUID().toString(), name, url, servers)
        profiles = if (existing != null) {
            profiles.map { if (it.id == existing.id) profile else it }
        } else {
            profiles + profile
        }
        storage.saveProfiles(profiles)
        if (selectedLink == null) select(servers.first().link)
    }

    private fun addSingle(link: String): Boolean {
        if (profiles.any { p -> p.servers.any { it.link == link } }) return false
        val name = LinkParser.serverName(link)
        val profile = Profile(UUID.randomUUID().toString(), name, null, listOf(Server(name, link)))
        profiles = profiles + profile
        storage.saveProfiles(profiles)
        if (selectedLink == null) select(link)
        return true
    }

    fun refresh(profile: Profile) {
        val url = profile.sourceUrl ?: return
        viewModelScope.launch {
            busy = true
            try {
                val result = SubscriptionClient.fetch(url)
                if (result.links.isEmpty()) {
                    toast("В подписке нет поддерживаемых серверов")
                } else {
                    upsertSubscription(url, result.title, result.links)
                    toast("Подписка обновлена: ${result.links.size} серверов")
                }
            } catch (e: Exception) {
                toast("Не удалось обновить: ${e.message ?: e.javaClass.simpleName}")
            }
            busy = false
        }
    }

    fun delete(profile: Profile) {
        profiles = profiles.filter { it.id != profile.id }
        storage.saveProfiles(profiles)
        if (profile.servers.any { it.link == selectedLink }) {
            if (connected) disconnect()
            selectedLink = null
            storage.selectedLink = null
        }
    }

    // ---------------------------------------------------------------- подключение

    fun selectedServer(): Server? =
        profiles.asSequence().flatMap { it.servers.asSequence() }.firstOrNull { it.link == selectedLink }

    fun select(link: String) {
        selectedLink = link
        storage.selectedLink = link
        if (connected) {
            core.stop()
            selectedServer()?.let { core.start(it) }
        }
    }

    fun toggleConnection() {
        if (connected) {
            disconnect()
            return
        }
        val server = selectedServer()
        if (server == null) {
            toast("Сначала выберите сервер")
            return
        }
        core.start(server)
        connected = true
    }

    private fun disconnect() {
        core.stop()
        connected = false
    }

    // ---------------------------------------------------------------- тема

    fun setThemeColor(key: String, hex: String) {
        theme = theme.withColor(key, hex)
        storage.saveTheme(theme)
    }

    fun pasteTheme(text: String) {
        try {
            theme = ThemeColors.applyJson(theme, text)
            storage.saveTheme(theme)
            toast("Тема применена")
        } catch (e: IllegalArgumentException) {
            toast(e.message ?: "Не удалось применить тему")
        }
    }

    fun resetTheme() {
        theme = ThemeColors()
        storage.saveTheme(theme)
    }
}

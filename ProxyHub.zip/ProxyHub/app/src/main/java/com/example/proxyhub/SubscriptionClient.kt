package com.example.proxyhub

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Загрузка подписки: ответ — base64-список или обычный список ссылок по строкам. */
object SubscriptionClient {

    class Result(val title: String?, val links: List<String>)

    private const val MAX_BYTES = 5_000_000

    suspend fun fetch(url: String): Result = withContext(Dispatchers.IO) {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "ProxyHub/1.0")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("сервер ответил HTTP $code")
            val bytes = conn.inputStream.use { it.readBytes() }
            if (bytes.size > MAX_BYTES) throw IllegalStateException("ответ слишком большой")
            val title = conn.getHeaderField("profile-title")?.let(::decodeTitle)
            Result(title, extractLinks(String(bytes, Charsets.UTF_8)))
        } finally {
            conn.disconnect()
        }
    }

    private fun decodeTitle(raw: String): String? {
        val t = raw.trim()
        val value = if (t.startsWith("base64:", ignoreCase = true)) decodeBase64Lenient(t.substring(7)) else t
        return value?.takeIf { it.isNotBlank() }
    }

    fun extractLinks(body: String): List<String> {
        val text = body.trim()
        val decoded = decodeBase64Lenient(text)
        val source = if (decoded != null && "://" in decoded) decoded else text
        return source.lineSequence()
            .map { it.trim() }
            .filter { schemeOf(it) in SERVER_SCHEMES }
            .toList()
    }
}

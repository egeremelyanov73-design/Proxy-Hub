package com.example.proxyhub

/** Один сервер: ссылка vless:// / vmess:// / trojan:// / ss:// и т.п. */
data class Server(val name: String, val link: String)

/** Профиль: подписка (sourceUrl != null) или одиночный сервер. */
data class Profile(
    val id: String,
    val name: String,
    val sourceUrl: String?,
    val servers: List<Server>,
)

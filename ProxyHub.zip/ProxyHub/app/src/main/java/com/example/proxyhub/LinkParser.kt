package com.example.proxyhub

import android.util.Base64
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

/** Что нашлось в тексте из буфера обмена, QR-кода или deep link. */
sealed interface Item {
    data class Subscription(val url: String) : Item
    data class ServerLink(val link: String) : Item
    data class Unsupported(val reason: String) : Item
}

val SERVER_SCHEMES = setOf("vless", "vmess", "trojan", "ss", "hysteria2", "hy2", "tuic")

fun schemeOf(s: String): String = if ("://" in s) s.substringBefore("://").lowercase() else ""

/** Base64 (обычный или URL-safe, с паддингом или без). null, если это не base64. */
fun decodeBase64Lenient(input: String): String? {
    val cleaned = input.filterNot { it.isWhitespace() }
        .replace('-', '+').replace('_', '/').trimEnd('=')
    if (cleaned.isEmpty()) return null
    val padded = cleaned + "=".repeat((4 - cleaned.length % 4) % 4)
    return try {
        String(Base64.decode(padded, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: IllegalArgumentException) {
        null
    }
}

object LinkParser {

    /**
     * Понимает:
     *  - happ://add/https://example.com/sub/...  (кнопка «Открыть в Happ»)
     *  - https://example.com/sub/...             (кнопка «Скопировать ссылку»)
     *  - vless:// vmess:// trojan:// ss:// hysteria2:// tuic:// — одиночные серверы
     * Несколько ссылок можно вставить сразу, по одной на строку.
     */
    fun parse(text: String): List<Item> =
        text.split(Regex("\\s+")).filter { it.isNotBlank() }.map { classify(it.trim()) }

    private fun classify(token: String): Item {
        val scheme = schemeOf(token)
        return when {
            scheme == "happ" -> {
                val rest = token.substring("happ://".length)
                val slash = rest.indexOf('/')
                val action = (if (slash >= 0) rest.substring(0, slash) else rest).lowercase()
                var payload = if (slash >= 0) rest.substring(slash + 1) else ""
                when {
                    action == "add" -> {
                        if ("://" !in payload && payload.contains("%3A", ignoreCase = true)) {
                            payload = runCatching { URLDecoder.decode(payload, "UTF-8") }.getOrDefault(payload)
                        }
                        classifyInner(payload)
                    }
                    action.startsWith("crypt") -> Item.Unsupported(
                        "Это зашифрованная ссылка (happ://$action). Расшифровать её нельзя — " +
                            "в боте нажмите «Скопировать ссылку» и вставьте обычную ссылку подписки."
                    )
                    else -> Item.Unsupported("Неизвестная ссылка Happ: happ://$action")
                }
            }
            else -> classifyInner(token)
        }
    }

    private fun classifyInner(s: String): Item {
        val scheme = schemeOf(s)
        return when {
            scheme == "http" || scheme == "https" -> Item.Subscription(s)
            scheme in SERVER_SCHEMES -> Item.ServerLink(s)
            else -> Item.Unsupported("Не похоже на ссылку конфигурации: ${s.take(40)}")
        }
    }

    /** Человекочитаемое имя сервера из ссылки. */
    fun serverName(link: String): String {
        val l = link.trim()
        if (l.startsWith("vmess://", ignoreCase = true)) {
            val ps = decodeBase64Lenient(l.substring(8))
                ?.let { runCatching { JSONObject(it).optString("ps") }.getOrNull() }
            return if (ps.isNullOrBlank()) "vmess" else ps
        }
        val fragment = l.substringAfter('#', "")
        if (fragment.isNotBlank()) {
            return runCatching { URLDecoder.decode(fragment, "UTF-8") }.getOrDefault(fragment)
        }
        val host = runCatching { URI(l).host }.getOrNull()
        return host ?: l.substringBefore("://")
    }
}
